package com.TokioCeap.bean;

public class Usuario {

}
