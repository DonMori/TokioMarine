package com.TokioCeap.bean;

public class Usuario {
	
	// 7 coisas pra por no banco
	private int cpf; // PK
	private String nome;
	private String email;
	private String sexo;
	private String senha;
	private int cep;
	private String data_Nasc;
	private int telefone;	
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public int getCep() {
		return cep;
	}
	public void setCep(int cep) {
		this.cep = cep;
	}
	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	public String getData_Nasc() {
		return data_Nasc;
	}
	public void setData_Nasc(String data_Nasc) {
		this.data_Nasc = data_Nasc;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	
}