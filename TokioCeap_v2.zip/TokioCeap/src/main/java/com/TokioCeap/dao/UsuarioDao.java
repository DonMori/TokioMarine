package com.TokioCeap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.TokioCeap.bean.Usuario;

public class UsuarioDao {
	// Regra de negócio
	
	public static Connection getConnection() {
		Connection con = null;
	
	try {
		Class.forName("com.mysql.jdbc.Driver"); // Nome do banco : TokioCeap
		con = DriverManager.getConnection("jdbc:mysql://localhost:3307/TokioCeap", "root", "");
		
	} catch (Exception e) {
		System.out.println(e);
	}
	return con;
	
	}

	// Listagem : Tem user?
							// pegarTodosUsuarios
	public static List<Usuario> getAllUsuarios() {
		List<Usuario> list = new ArrayList<Usuario>();
		
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * FROM usuario");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Usuario usuario = new Usuario();
				// Todos os campos referentes ao user
				usuario.setCpf(rs.getInt("cpf"));
				usuario.setNome(rs.getString("nome"));
				usuario.setEmail(rs.getString("email"));
				usuario.setSexo(rs.getString("sexo"));
				usuario.setSenha(rs.getString("senha"));
				usuario.setCep(rs.getInt("cep"));
				usuario.setData_Nasc(rs.getString("data_Nasc"));
				usuario.setTelefone(rs.getInt("telefone"));
				
				list.add(usuario);
			}
			
			
		} catch (Exception e) {
			System.out.println(e);
		} // Todo o código, da linha 31 até a 57 será chamado em uma página html
		
		return list;
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}